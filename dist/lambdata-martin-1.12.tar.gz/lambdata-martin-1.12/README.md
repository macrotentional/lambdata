# lambdata-ds15

## This is where I would upload packages for python

## Installation

```sh
pip install -i https://test.pypi.org/simple/ lambdata-ds15
```

## Usage

### Enlarges inpput by 100

```py
from my_lambdata.my_mod import enlarge
print(enlarge(8))
```

### Adds three new columns to a dataframe after converting a column to a datetime format

```py
from my_lambdata.practice_mod1 import checks_null
checks_null(df)
```

### Checks dataframe for nulls and returns sum of NaNs

```py
from my_lambdata.practice_mod2 import checksfornulls
checks_null(df)
```

<hr>

this is a list:

+ item 1
+ item 2