
from pandas import DataFrame
#import pandas as pd

from my_lambdata.my_mod import enlarge

print("HELLO")

print(enlarge(8))

